package com.example.ggcs_main;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Button_game_setting extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.button_game_setting);
    }
}
